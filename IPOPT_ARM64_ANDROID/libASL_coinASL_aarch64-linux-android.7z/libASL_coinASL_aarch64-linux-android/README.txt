create symlinks ln -s 
from 
./include/coin-or/asl/asl.h
./include/coin-or/asl/asl_pfg.h
./include/coin-or/asl/asl_pfgh.h
to 
./include/coin/ThirdParty/asl.h
./include/coin/ThirdParty/asl_pfg.h
./include/coin/ThirdParty/asl_pfgh.h

check any broken links by readlink or du -sh
4.0K    ./lib/libcoinasl.la
548K    ./lib/libcoinasl.so
0       ./lib/libcoinasl.so.1 <-- a symlink identified bt size
552K    ./lib/libcoinasl.so.1.4.4
