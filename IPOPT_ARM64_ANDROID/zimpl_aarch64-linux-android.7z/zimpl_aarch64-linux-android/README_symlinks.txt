.
├── bin
│   └── zimpl
├── include
│   └── zimpl
│       ├── attribute.h
│       ├── bliss -> /data/data/com.termux/files/usr/local/include/bliss
│       ├── blkmem.h
│       ├── blockmemshell -> /data/data/com.termux/files/usr/local/include/blockmemshell
│       ├── bound.h
│       ├── code.h
│       ├── coin -> /data/data/com.termux/files/usr/local/include/coin
│       ├── coin-or -> /data/data/com.termux/files/usr/local/include/coin-or
│       ├── conname.h
│       ├── define.h
│       ├── dijkstra -> /data/data/com.termux/files/usr/local/include/dijkstra
│       ├── dmumps_c.h -> ./dmumps_c.h
│       ├── elem.h
│       ├── entry.h
│       ├── fmt -> /data/data/com.termux/files/usr/local/include/fmt
│       ├── gmpmisc.h
│       ├── hash.h
│       ├── heap.h
│       ├── idxset.h
│       ├── inst.h
│       ├── lint.h
│       ├── list.h
│       ├── local.h
│       ├── lpi -> /data/data/com.termux/files/usr/local/include/lpi
│       ├── metaio.h
│       ├── metis.h -> /data/data/com.termux/files/usr/local/include/metis.h
│       ├── metis.h.gch -> /data/data/com.termux/files/usr/local/include/metis.h.gch
│       ├── mme.h
│       ├── mmlparse2.h
│       ├── mono.h
│       ├── mshell.h
│       ├── mumps_c_types.h -> ./mumps_c_types.h
│       ├── mumps_compat.h -> ./mumps_compat.h
│       ├── mumps_int_def.h -> ./mumps_int_def.h
│       ├── mumps_mpi.h -> ./mumps_mpi.h
│       ├── numb.h
│       ├── objscip -> /data/data/com.termux/files/usr/local/include/objscip
│       ├── papilo -> /data/data/com.termux/files/usr/local/include/papilo
│       ├── prog.h
│       ├── random.h
│       ├── ratlp.h
│       ├── ratlpstore.h
│       ├── ratlptypes.h
│       ├── rdefpar.h
│       ├── scip -> /data/data/com.termux/files/usr/local/include/scip
│       ├── set.h
│       ├── set4.h
│       ├── smumps_c.h -> ./smumps_c.h
│       ├── soplex -> /data/data/com.termux/files/usr/local/include/soplex
│       ├── soplex.h -> /data/data/com.termux/files/usr/local/include/soplex.h
│       ├── soplex.hpp -> /data/data/com.termux/files/usr/local/include/soplex.hpp
│       ├── soplex_interface.h -> /data/data/com.termux/files/usr/local/include/soplex_interface.h
│       ├── stkchk.h
│       ├── stmt.h
│       ├── strstore.h
│       ├── symbol.h
│       ├── symmetry -> /data/data/com.termux/files/usr/local/include/symmetry
│       ├── tclique -> /data/data/com.termux/files/usr/local/include/tclique
│       ├── term.h
│       ├── tinycthread -> /data/data/com.termux/files/usr/local/include/tinycthread
│       ├── tpi -> /data/data/com.termux/files/usr/local/include/tpi
│       ├── tuple.h
│       ├── xlpglue.h
│       ├── xml -> /data/data/com.termux/files/usr/local/include/xml
│       ├── zimpllib.h
│       └── zlpglue.h
├── lib
│   ├── cmake
│   │   └── zimpl
│   │       ├── zimpl-config-version.cmake
│   │       ├── zimpl-config.cmake
│   │       ├── zimpl-targets-relwithdebinfo.cmake
│   │       └── zimpl-targets.cmake
│   ├── libzimpl-pic.a
│   └── libzimpl.a
└── tree_symlinks.txt

22 directories, 58 files
