/* src/config_couenne.h.  Generated from config_couenne.h.in by configure.  */
/* src/config_couenne.h.in. */

#ifndef __CONFIG_COUENNE_H__
#define __CONFIG_COUENNE_H__

/* whether CouenneInterface is derived from Bonmin's AmplInterface */
#define COUENNEINTERFACE_FROM_ASL 1

/* Library Visibility Attribute */
#define COUENNELIB_EXPORT 

/* Version number of project */
#define COUENNE_VERSION "devel"

/* Major Version number of project */
#define COUENNE_VERSION_MAJOR 9999

/* Minor Version number of project */
#define COUENNE_VERSION_MINOR 9999

/* Release Version number of project */
#define COUENNE_VERSION_RELEASE 9999

#endif
