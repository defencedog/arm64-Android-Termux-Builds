create a symlink
ln -s ./lib/libcoinhsl.so ./lib/libhsl.so
