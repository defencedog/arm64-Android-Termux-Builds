pkg i zlib coinor-clp

ln -s ./lib/libCoinUtils.so /data/data/com.termux/files/usr/lib/libCoinUtils.so
