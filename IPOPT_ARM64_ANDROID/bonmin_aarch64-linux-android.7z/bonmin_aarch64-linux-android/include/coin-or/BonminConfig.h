/* src/Interfaces/config_bonmin.h.  Generated from config_bonmin.h.in by configure.  */
/* src/Interfaces/config_bonmin.h.in. */

#ifndef __CONFIG_BONMIN_H__
#define __CONFIG_BONMIN_H__

/* Library Visibility Attribute */
#define BONMINAMPLINTERFACELIB_EXPORT 

/* Library Visibility Attribute */
#define BONMINLIB_EXPORT 

/* Version number of project */
#define BONMIN_VERSION "devel"

/* Major Version number of project */
#define BONMIN_VERSION_MAJOR 9999

/* Minor Version number of project */
#define BONMIN_VERSION_MINOR 9999

/* Release Version number of project */
#define BONMIN_VERSION_RELEASE 9999

#endif
