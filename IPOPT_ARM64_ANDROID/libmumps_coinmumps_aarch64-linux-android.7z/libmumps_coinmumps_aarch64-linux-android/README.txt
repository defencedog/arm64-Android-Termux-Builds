ln -s ./lib/pkgconfig/coinmumps.pc ./lib/pkgconfig/mumps.pc
ln -s ./lib/libcoinmumps.so ./lib/libmumps.so

create symlinks 
from
./include/coin-or/mumps/mumps_c_types.h
./include/coin-or/mumps/mumps_mpi.h
./include/coin-or/mumps/mumps_compat.h
./include/coin-or/mumps/mumps_int_def.h
./include/coin-or/mumps/dmumps_c.h
./include/coin-or/mumps/smumps_c.h
to
./include/mumps_c_types.h
./include/dmumps_c.h
./include/mumps_compat.h
./include/mumps_int_def.h
./include/mumps_mpi.h
./include/smumps_c.h

 
