/* mumps_int_def.h.  Generated from mumps_int_def.h.in by configure.  */
#ifndef MUMPS_INT_H
#define MUMPS_INT_H

/* Define if MUMPS integers have a size of 32-bit */
#define MUMPS_INTSIZE32 /**/

/* Define if MUMPS integers have a size of 64-bit */
/* #undef MUMPS_INTSIZE64 */

#endif
