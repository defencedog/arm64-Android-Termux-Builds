ln -s ./include/metis.h.gch ./include/coin/ThirdParty/metis.h.gch






